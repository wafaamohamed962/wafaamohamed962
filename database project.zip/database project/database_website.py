import streamlit as st
from sqlalchemy import create_engine, text
import pandas as pd

# Database connection string
engine = create_engine('mysql+pymysql://root:@localhost/coursera')

# Function to get table names from the database
def get_table_names():
    with engine.connect() as connection:
        result = connection.execute(text("SHOW TABLES"))
        return [row[0] for row in result]

# Function to get column names for a given table
def get_column_names(table_name):
    with engine.connect() as connection:
        result = connection.execute(text(f"SHOW COLUMNS FROM {table_name}"))
        return [column[0] for column in result]

# Function to insert new user into the database
def insert_user(username, password, user_type):
    sql = text("INSERT INTO user (username, password, user_type) VALUES (:username, :password, :user_type)")
    with engine.begin() as connection:
        connection.execute(sql, {'username': username, 'password': password, 'user_type': user_type})

# Function to check user credentials
def check_credentials(username, password):
    query = text("SELECT * FROM user WHERE username=:username AND password=:password")
    with engine.connect() as connection:
        result = connection.execute(query, {'username': username, 'password': password}).fetchone()
        return result is not None

# Function to insert data into the selected table
def insert_data(table_name, data):
    placeholders = ', '.join([':%s' % column for column in data])
    sql = text(f"INSERT INTO {table_name} ({', '.join(data.keys())}) VALUES ({placeholders})")
    with engine.begin() as connection:
        connection.execute(sql, data)

# Registration page layout
def registration_page():
    st.title('Registration Page')
    with st.form("registration_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        user_type = st.selectbox("Are you a student or an admin?", ('student', 'admin'))
        submit_button = st.form_submit_button("Register")
        if submit_button:
            insert_user(username, password, user_type)
            st.success("You have successfully registered!")

# Login page layout
def login_page():
    st.title('Login Page')
    username = st.text_input("Username", key="login_username")
    password = st.text_input("Password", type="password", key="login_password")
    if st.button("Login"):
        if check_credentials(username, password):
            st.session_state['login_status'] = True
            st.session_state['current_page'] = 'options'
            st.success("Login successful!")
        else:
            st.error("Invalid username or password.")

# Landing page layout
def landing_page():
    st.title('S3udi Database')
    if st.session_state['login_status']:
        st.session_state['current_page'] = 'options'
    else:
        if st.button("Login"):
            st.session_state['current_page'] = 'login'
        if st.button("Register"):
            st.session_state['current_page'] = 'register'

# Options page layout
def options_page():
    st.title('Options')
    if st.button('Show Tables'):
        st.session_state['current_page'] = 'show_tables'
    elif st.button('Show Queries'):
        st.session_state['current_page'] = 'show_queries'
    elif st.button('Insert into Tables'):
        st.session_state['current_page'] = 'insert_into_tables'
    elif st.button('Search by Student ID'):
        st.session_state['current_page'] = 'search_by_id'
    elif    st.button('Import File'):
        st.session_state['current_page'] = 'import_file'

# Search by Student ID page layout
def search_by_id_page():
    st.title('Search by Student ID')
    student_id = st.text_input('Enter Student ID:')
    search_button = st.button('Search')

    if search_button and student_id:
        with engine.connect() as connection:
            try:
                result = connection.execute(text(f"SELECT St_name, Email FROM Student WHERE Student_ID = :id"), {'id': student_id})
                data = result.fetchone()
                if data:
                    st.write(f"Student Name: **{data[0]}**")
                    st.write(f"Email: **{data[1]}**")
                else:
                    st.warning('No student found with that ID.')
            except Exception as e:
                st.error(f"An error occurred: {e}")
# Show tables page layout
def show_tables_page():
    st.title('Show Tables')
    if st.button('Back'):
        st.session_state['current_page'] = 'options'
    else:
        table_names = get_table_names()
        selected_table = st.selectbox("Select a table to display", table_names)
        if st.button("Display Table"):
            def fetch_table_data(table_name):
                sql = text(f"SELECT * FROM {table_name}")
                with engine.connect() as connection:
                    result = connection.execute(sql)
                    return result.fetchall()
            data = fetch_table_data(selected_table)
            if data:
                st.write(f"Data from {selected_table}:")
                st.table(data)
            else:
                st.write(f"No data available for {selected_table}.")
# Show queries page layout
def show_queries_page():
    st.title('Show Queries')
    if st.button('Back'):
        st.session_state['current_page'] = 'options'
    else:
        # List of views
        views = {
            'Enrolled Students Per Course': "View_EnrolledStudentsPerCourse",
            'Students With No Completion': "View_StudentsWithNoCompletion",
            'Total Students Per Instructor': "View_TotalStudentsPerInstructor",
            'Uncompleted Courses': "View_UncompletedCourses",
            'Multi-Course Instructors': "View_MultiCourseInstructors",
            'Total Enrolled Students Per Course': "View_TotalEnrolledStudentsPerCourse",
            'AIU Fields Coursera Usage': "AIUFieldsCourseraUsage"
        }

        # Dropdown to select a view
        selected_view = st.selectbox("Select a view to display:", list(views.keys()))
        display_view_button = st.button("Display Selected View")

        if display_view_button:
            view_name = views[selected_view]
            with engine.connect() as connection:
                try:
                    result = connection.execute(text(f"SELECT * FROM {view_name}"))
                    data = result.fetchall()
                    st.write(f"Data from {view_name}:")
                    st.table(data)
                except Exception as e:
                    st.error(f"An error occurred: {e}")

            st.subheader('Search by Student ID')
    student_id = st.text_input('Enter Student ID:')
    search_button = st.button('Search')

    if search_button and student_id:
        with engine.connect() as connection:
            try:
                result = connection.execute(text(f"SELECT St_name, Email FROM Student WHERE Student_ID = :id"), {'id': student_id})
                data = result.fetchone()
                if data:
                    # Use index position based on the order of columns in the SELECT statement
                    st.write(f"Student Name: **{data[0]}**")
                    st.write(f"Email: **{data[1]}**")
                else:
                    st.warning('No student found with that ID.')
            except Exception as e:
                st.error(f"An error occurred: {e}")
# Insert into tables page layout
def insert_into_tables_page():
    st.title('Insert into Tables')
    if st.button('Back'):
        st.session_state['current_page'] = 'options'
    else:
        table_names = get_table_names()
        selected_table = st.selectbox("Select a table to insert data into", table_names)
        if selected_table:
            column_names = get_column_names(selected_table)
            with st.form("data_insert_form"):
                data = {column: st.text_input(f"Enter {column}") for column in column_names}
                submit_button = st.form_submit_button("Insert Data")
                if submit_button:
                    insert_data(selected_table, data)
                    st.success(f"Data inserted into {selected_table} successfully!")

def import_csv_data(table_name, file):
    df = pd.read_csv(file)
    df.to_sql(table_name, con=engine, if_exists='append', index=False)
    st.success(f"Data from the CSV file has been successfully imported into the {table_name} table.")

# Import file page layout
def import_file_page():
    st.title('Import File')
    if st.button('Back'):
        st.session_state['current_page'] = 'options'
    else:
        uploaded_file = st.file_uploader("Choose a CSV file")
        if uploaded_file is not None:
            table_names = get_table_names()
            selected_table = st.selectbox("Select a table to import data into", table_names)
            if st.button("Import"):
                import_csv_data(selected_table, uploaded_file)

# Initialize session state variables if they don't exist
if 'current_page' not in st.session_state:
    st.session_state['current_page'] = 'landing'
    st.session_state['login_status'] = False

def main():
    if st.session_state['login_status']:
        if st.session_state['current_page'] == 'options':
            options_page()
        elif st.session_state['current_page'] == 'show_tables':
            show_tables_page()
        elif st.session_state['current_page'] == 'show_queries':
            show_queries_page()
        elif st.session_state['current_page'] == 'insert_into_tables':
            insert_into_tables_page()
        elif st.session_state['current_page'] == 'search_by_id':
            search_by_id_page()
        elif st.session_state['current_page'] == 'import_file':
         import_file_page()    
        else:
            landing_page()
    elif st.session_state['current_page'] == 'landing':
        landing_page()
    elif st.session_state['current_page'] == 'login':
        login_page()
    elif st.session_state['current_page'] == 'register':
        registration_page()
   

if __name__ == "__main__":
    main()